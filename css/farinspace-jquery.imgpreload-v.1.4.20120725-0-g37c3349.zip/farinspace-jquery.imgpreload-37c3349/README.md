[jQuery Image Preload Plugin][imgpreload]
=========================

The jQuery imgpreload plugin lets you preload images before and/or after the DOM is loaded.

Tested: IE6, IE7, IE8, IE9, FF, Chrome, Safari

http://farinspace.com/jquery-image-preload-plugin

https://github.com/farinspace/jquery.imgpreload

Licensed under the MIT license
http://en.wikipedia.org/wiki/MIT_License

[imgpreload]: http://farinspace.com/jquery-image-preload-plugin/ "jQuery Image Preload Plugin"